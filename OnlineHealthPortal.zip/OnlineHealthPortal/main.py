# -*- coding: utf-8 -*-
import sqlite3
from flask import Flask, request, session, redirect, url_for
from flask import render_template
import sys

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/start', methods=['GET'])
def start():
    return render_template('start.html')

@app.route('/background', methods=['GET'])
def background():
    return render_template('background.html')


@app.route('/start', methods=['POST'])
def datasubmittedstart():
    gender_entered = request.form['message']
    if gender_entered == "":
        gender_entered = 'blank'
    # You can create dummy USER table with User_ID(Identity Column) and gender in sqlite database and insert gender

    with sqlite3.connect('ANTI_DEP.db', isolation_level=None) as conn:
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS USER (USER_ID INTEGER PRIMARY KEY AUTOINCREMENT, gender)")
        cursor.execute("INSERT INTO USER(gender) VALUES ('%s')" % (gender_entered))
        conn.commit()

        cursor.execute("SELECT MAX(USER_ID) FROM USER")
        result_set = cursor.fetchall()

    session["userId"] = result_set[0][0]

    return redirect('/illness')


@app.route('/illness', methods=['GET'])
def illness():
    return render_template('illness.html')


@app.route('/illness', methods=['POST'])
def datasubmittedillness():
    illness_entered = request.form['name']
    if illness_entered == "":
        illness_entered = 'blank'
    elif ((illness_entered.find('headache') != -1) or (illness_entered.find('head') != -1)):
        illness_entered = 'headache'  
    elif ((illness_entered.find('vomiting') != -1) or (illness_entered.find('vomit') != -1) or (illness_entered.find('throwing up') != -1)):  
        illness_entered = 'vomiting' 
    elif ((illness_entered.find('diabetes') != -1) or (illness_entered.find('high blood sugar') != -1) or (illness_entered.find('blood sugar') != -1) or (illness_entered.find('sugar') != -1)):  
        illness_entered = 'diabetes'     
    else:
        illness_entered =illness_entered     
    userId = session["userId"]
    session["illness_entered1stIteration"]=illness_entered
    
    with sqlite3.connect('ANTI_DEP.db', isolation_level=None) as conn:
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS USER_RESPONSE (USER_SESSION, DISEASE_RESPONSE)")
        cursor.execute("INSERT INTO USER_RESPONSE(USER_SESSION, DISEASE_RESPONSE) VALUES ('%s', '%s')" % (userId, illness_entered.lower()))
        conn.commit()
        
        sid = "select count(c.ICD_CD_TRIM) freq, c.CATEGORY from MRXNW_ENG a inner join umls_icd9cm_subset b on a.cui=b.CUICODE  inner join CATEGORY_MATCH c on b.ICD9_TRIM =  c.ICD_CD_TRIM  where a.text = '%s'  group by c.CATEGORY order by freq desc limit 1" %(illness_entered.lower())
        cursor.execute(sid)
        #result_set = cursor.fetchall()
        x =""
        print('This is standard output', file=sys.stdout)
        print(cursor.rowcount, file=sys.stdout)
        resultcount = cursor.fetchall()
        print(len(resultcount), file=sys.stdout)
        
        #if cursor.rowcount == -1:
        if len(resultcount) == 0:#we need one row to be returned by query to prevent exception
            x ="No disease found for the keyword you entered. Please enter different diesease in the textbox below:"
            session["userdiagnosis"] = x
        else:
            result_set = resultcount
            x=result_set[0][1]
            session["userdiagnosis"] =" A "+ x +" "+"disease was added to your profile. Please add another disease:"
    
    return redirect(url_for('confirmresponse', uid1=userId)) #Redirecting the page with userId in queury string


@app.route('/confirmresponse', methods=['GET'])  #This section to pass name uid1 as name to confirmresponse.html page
def confirmresponse():
    uid1 = request.args.get('uid1') #This section getting value from query string, it is already in session
    userdiagnosis = session["userdiagnosis"]
    return render_template('confirmresponse.html', name=userdiagnosis)
    #return render_template('confirmresponse.html', name=uid1)



@app.route('/confirmresponsesecond', methods=['POST'])
def confirmresponsesecond():
    #return render_template('confirmresponsesecond.html')
    with sqlite3.connect('ANTI_DEP.db', isolation_level=None) as conn:
        cursor = conn.cursor()
        illness_entered1stIteration= session["illness_entered1stIteration"]
        sid = "select count(c.ICD_CD_TRIM) freq, c.CATEGORY from MRXNW_ENG a inner join umls_icd9cm_subset b on a.cui=b.CUICODE  inner join CATEGORY_MATCH c on b.ICD9_TRIM =  c.ICD_CD_TRIM  where a.text = '%s'  group by c.CATEGORY order by freq desc limit 2" %(illness_entered1stIteration.lower())
        cursor.execute(sid)
        #result_set = cursor.fetchall()
        x =""
        resultcount = cursor.fetchall()
        if (len(resultcount) == 1 or len(resultcount) == 0): #we need 2 rows to be returned by query to prevent exception
            x ="No more disease found for the keyword you entered. Please click back arrow to go back and enter different diesease in Illness textbox!!!"
        else:
            result_set = resultcount
            x="Well then we will add "+ result_set[1][1] +" disease to your profile."

    userdiagnosissecond = x 
    #userdiagnosissecond = result_set[1][1]
    return render_template('confirmresponsesecond.html',name=userdiagnosissecond)

@app.route('/confirmresponsethird', methods=['POST'])
def confirmresponsethird():
    #return render_template('confirmresponsesecond.html')
    with sqlite3.connect('ANTI_DEP.db', isolation_level=None) as conn:
        cursor = conn.cursor()
        illness_entered1stIteration= session["illness_entered1stIteration"]
        sid = "select count(c.ICD_CD_TRIM) freq, c.CATEGORY from MRXNW_ENG a inner join umls_icd9cm_subset b on a.cui=b.CUICODE  inner join CATEGORY_MATCH c on b.ICD9_TRIM =  c.ICD_CD_TRIM  where a.text = '%s'  group by c.CATEGORY order by freq desc limit 3" %(illness_entered1stIteration.lower())
        cursor.execute(sid)
        #result_set = cursor.fetchall()
        x =""
        resultcount = cursor.fetchall()
        if (len(resultcount) == 2 or len(resultcount) == 1 or len(resultcount) == 0): #we need 3 rows to be returned by query to prevent exception
            x ="No more disease found for the keyword you entered. Please click back arrow to go back and enter different diesease in Illness textbox"
        else:
            result_set = resultcount
            x="Finally we will add "+ result_set[2][1] +" disease to your profile."
    userdiagnosisthird = x   
    #userdiagnosisthird = result_set[2][1]
    return render_template('confirmresponsethird.html',name=userdiagnosisthird)


@app.route('/final', methods=['POST'])
def final():
    return render_template('final.html')



if __name__ == "__main__":
    app.secret_key = 'super secret key'
    app.config['SESSION_TYPE'] = 'filesystem'
    # sess.init_app(app)

    app.run(debug=True)
